package com.example.financetrackerapp

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val nameField = findViewById<EditText>(R.id.editTextName)
        val passwordField = findViewById<EditText>(R.id.editTextPassword)
        val loginButton = findViewById<Button>(R.id.buttonLogin)
        val signupLink = findViewById<TextView>(R.id.textSignup)

        loginButton.setOnClickListener {
            val name = nameField.text.toString().trim()
            val password = passwordField.text.toString()

            // Validate inputs
            when {
                name.isEmpty() -> {
                    nameField.error = "Email cannot be empty"
                    nameField.requestFocus()
                }
                !name.matches(Regex("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}\$")) -> {
                    nameField.error = "Please enter a valid email address"
                    nameField.requestFocus()
                }

                password.isEmpty() -> {
                    passwordField.error = "Password cannot be empty"
                    passwordField.requestFocus()
                }
                password.length < 8 -> {
                    passwordField.error = "Password must be at least 8 characters"
                    passwordField.requestFocus()
                }
                else -> {
                    // If validation passes, navigate to HomeActivity
                    if (name.isNotEmpty() && password.isNotEmpty()) {
                        //  Navigate to HomeActivity
                        val loginButton = findViewById<Button>(R.id.buttonLogin)
                        loginButton.setOnClickListener {
                            val intent = Intent(this, HomeActivity::class.java)
                            startActivity(intent)
                        }
                    } else {
                        Toast.makeText(this, "Please enter name and password", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        signupLink.setOnClickListener {
            startActivity(Intent(this, SignupActivity::class.java))
        }
    }
}
