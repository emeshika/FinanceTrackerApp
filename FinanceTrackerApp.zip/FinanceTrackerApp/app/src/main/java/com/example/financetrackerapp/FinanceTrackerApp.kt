package com.example.financetrackerapp

import android.app.Application
import android.content.Context
import androidx.appcompat.app.AppCompatDelegate

class FinanceTrackerApp : Application() {
    override fun onCreate() {
        super.onCreate()
        
        // Initialize theme based on saved preference
        val prefs = getSharedPreferences("Settings", Context.MODE_PRIVATE)
        val isDarkMode = prefs.getBoolean("dark_mode", false)
        
        if (isDarkMode) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }
    }
} 