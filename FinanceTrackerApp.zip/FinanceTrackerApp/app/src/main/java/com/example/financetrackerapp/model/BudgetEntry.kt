package com.example.financetrackerapp.model

data class BudgetEntry(
    val date: String,
    val reason: String,
    val amount: Double,
    val type: String
)